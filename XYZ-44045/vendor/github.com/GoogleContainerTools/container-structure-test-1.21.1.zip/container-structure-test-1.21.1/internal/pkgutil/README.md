This package was copied over from [container-diff](https://github.com/GoogleContainerTools/container-diff) to remove our dependency on it. That project is too hard to maintain.

project: https://github.com/GoogleContainerTools/container-diff

commit: ae4befd09f92caf735cdd63794ae2fa9f2efc5e3

path: ./pkg/util